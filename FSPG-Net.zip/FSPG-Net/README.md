
# [FSPG-Net: A Frequency-Spatial Synergistic-Decoupling and Phase Guided Network for SAR Ship Detection](https://ieeexplore.ieee.org/document/10757443)



### 💾Environment
Our environment: Ubuntu 22.04, CUDA 11.8, NVIDIA RTX A4000 GPU.

Use conda to create the conda environment and activate it:
```shell
conda env create --name your_env_name python=3.8
conda activate your_env_name
pip install ultralytics
```
### 📈Training
Check the path in [train.py](./train.py), and run it to train:
```shell
python train.py 
```
### 📝Validation
Check the path in [val.py](./val.py).

```shell
python val.py
```

## Acknowledgement

The code base is built with [ultralytics](https://github.com/ultralytics/ultralytics).

Thanks for the great implementations! 






